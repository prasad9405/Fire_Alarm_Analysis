import pandas as pd
from sklearn.model_selection import *
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
from datetime import datetime
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
import numpy as np


df10=pd.read_csv('/home/student/Downloads/october.2018-bostonfireincidentopendata.csv')
df9=pd.read_csv('/home/student/Downloads/september.2018-bostonfireincidentopendata.csv')
df12=pd.read_csv('/home/student/Downloads/december.2018-bostonfireincidentopendata.csv')
df8=pd.read_csv('/home/student/Downloads/august.2018-bostonfireincidentopendata.csv')
df11=pd.read_csv('/home/student/Downloads/november.2018-bostonfireincidentopendata.csv')
df5=pd.read_csv('/home/student/Downloads/may.2018-bostonfireincidentopendata.csv')
df6=pd.read_csv('/home/student/Downloads/june.2018-bostonfireincidentopendata.csv')
df4=pd.read_csv('/home/student/Downloads/april.2018-bostonfireincidentopendata.csv')
df7=pd.read_csv('/home/student/Downloads/july.2018-bostonfireincidentopendata.csv')
df1=pd.read_csv('/home/student/Downloads/january.2018-bostonfireincidentopendata.csv')
df3=pd.read_csv('/home/student/Downloads/march.2018-bostonfireincidentopendata.csv')
df22=pd.read_csv('/home/student/Downloads/february.2018-bostonfireincidentopendata.csv')

result = pd.concat([df1,df22,df3,df4,df5,df6,df7,df8,df9,df10,df11,df12])
df2=result
##########################################################################
#df2=pd.read_csv('/home/student/Downloads/march.2018-bostonfireincidentopendata.csv')
file2=pd.read_csv("/home/student/Downloads/property-use-code-list.csv")
file3=pd.read_csv("/home/student/Downloads/incident-type-code-list.csv")

df2['Property Use']=pd.to_numeric(df2['Property Use'], errors='coerce')
df2['Incident Type']=pd.to_numeric(df2['Incident Type'], errors='coerce')
file2['code']=pd.to_numeric(file2['code'], errors='coerce')
file3['code']=pd.to_numeric(file3['code'], errors='coerce')

df2=df2.dropna()
file2=file2.dropna()
file3=file3.dropna()


file2 = file2.rename({'code': 'Property Use'}, axis=1)
file3 = file3.rename({'code': 'Incident Type'}, axis=1)
df2['month'] = pd.DatetimeIndex(df2['Alarm Date']).month
##"Incident Description"
boston_fire=df2
del_col_list=["Exposure Number","Alarm Date","Alarm Time","Neighborhood"
              ,"Property Description","Street Number","Street Prefix","Street Suffix"
              ,"Address 2","XStreet Prefix","XStreet Name","XStreet Suffix"
              ,"XStreet Type"]
boston_fire=boston_fire.drop(del_col_list,axis=1)

join_code=pd.merge(boston_fire,file2,on=['Property Use','Property Use'],how='left')
#join_code=boston_fire.merge(file2,how='left')
all_join=pd.merge(join_code,file3,on=['Incident Type','Incident Type'],how='left')
all_join['Incident Number']=all_join['Incident Number'].str.lstrip('18- ')

#################################################################################
all_join['Street Type']=all_join['Street Type'].dropna()
distinct_city_section = all_join.groupby(['month','City Section']).nunique()
distinct_street_type = boston_fire.groupby(['month','Street Type']).nunique()
distinct_Incident_type = boston_fire.groupby(['month','Incident Type']).nunique()

all_join.to_csv('/home/student/Desktop/all_join.csv')
#distinct_property = boston_fire.groupby(['month','Estimated Property Loss']).sum()
#
#distinct_property = boston_fire['Estimated Property Loss'].sum

del_col_list_city=["Incident Type","Estimated Property Loss","Estimated Content Loss"
                     ,"District","City Section","Zip","month","Street Type",
                     "category_x","grp_x","descript_x","category_y","grp_y"
                     ,"descript_y"]


del_col_list_street=["Incident Type","Estimated Property Loss","Estimated Content Loss"
                     ,"District","City Section","Zip","Street Type","month"]

del_col_list_incident=["Incident Type","Estimated Property Loss","Estimated Content Loss"
                     ,"District","City Section","Zip","Street Type","month"]
distinct_city_section=distinct_city_section.drop(del_col_list_city,axis=1)
distinct_street_type=distinct_street_type.drop(del_col_list_street,axis=1)
distinct_Incident_type=distinct_Incident_type.drop(del_col_list_incident,axis=1)

## separating particular month
january=all_join[all_join['month'] == 1]

feature_vector = pd.concat([distinct_city_section,distinct_street_type,distinct_Incident_type])


#distinct_city_section.to_csv('/home/student/Desktop/city_section.csv')
#all_join.to_csv('/home/student/Desktop/all_join.csv')

#distinct_description = boston_fire.groupby(['Incident Description']).nunique()

x=all_join.iloc[:,[2]].values
x=pd.DataFrame(x)
    
x_list = x.values.tolist()
j=0
for i in x_list:
      s =str(i)
      if(s.find("false")!=-1):
          x_list[j] =0 
      else:
          x_list[j] =1
      j=j+1
          
aa=pd.DataFrame(x_list)

#all_join=pd.concat([all_join, aa], ignore_index=True, sort =False)



###Machine Learning Part
del_12=["Incident Number","Estimated Property Loss"
        ,"Estimated Content Loss","District","Zip"
        ,"Street Name","Street Type","month","category_x","grp_x"
        ,"descript_x","category_y","grp_y","descript_y"]
ml=all_join.drop(del_12,axis=1)
#ml.to_csv('/home/student/Desktop/ml.csv')
#ml['City Section']=pd.get_dummies(ml['City Section'])

labelencoder1=LabelEncoder()
ml['City Section']=labelencoder1.fit_transform(ml['City Section'])
ml['Incident Description']=labelencoder1.fit_transform(ml['Incident Description'])

x=ml.iloc[:,[0,2,3]].values 
y=aa.iloc[:,0].values
sc_X=StandardScaler()
sc_y=StandardScaler()
X=sc_X.fit_transform(x)
#y=sc_y.fit_transform(y)

#Splitting the dataset into the training set and test set
x_train,x_test,y_train,y_test=train_test_split(X,y,test_size=0.30,random_state=0)


##################################################################
####Classifier

#########################################################################
###Naive Bayes classifier
from sklearn.naive_bayes import GaussianNB
classifier=GaussianNB()
classifier.fit(x_train,y_train)
#predicting the test set results
y_pred=classifier.predict(x_test)


##########################################################################
### Support vector Classifier
from sklearn.svm import SVC
classifier=SVC(kernel="rbf",random_state=0)
classifier.fit(x_train,y_train)
#predicting the test set results
y_pred=classifier.predict(x_test)

#########################################################################
##################################################################
### KNN Classifier
from sklearn.neighbors import KNeighborsClassifier
classifier=KNeighborsClassifier(n_neighbors=5,metric='minkowski',p=2)
classifier.fit(x_train,y_train)
y_pred=classifier.predict(x_test)


### Random Forest Classifier
from sklearn.ensemble import RandomForestClassifier
classifier=RandomForestClassifier(n_estimators=10,criterion="entropy")
classifier.fit(x_train,y_train)
#predicting the test set results
y_pred=classifier.predict(x_test)


#model accuracy,how often is the classifier correct?
from sklearn.metrics import confusion_matrix
cm=confusion_matrix(y_test,y_pred)

#from sklearn import metrics
#print("Accuracy :",metrics.accuracy_score(y_test,y_pred)*100,"%")
correct=cm[0,1]+cm[1,0]

##save result into the log file (text file)
with open (r"/home/student/Desktop/Result_Fire.txt","a") as file:
    file.write("False Alarm's in Boston City for the Year-2018 are :")
    file.write(str(correct))
    file.write("\n")
##feature scaling
#regressor=LinearRegression()
#regressor.fit(x_train,y_train)
#######################################################################

##fitting polynomial Regression to the dataset
#from sklearn.preprocessing import PolynomialFeatures
#poly_reg=PolynomialFeatures(degree=4)
#X_poly=poly_reg.fit_transform(X)
#poly_reg.fit(X_poly,y)
#lin_reg_2=LinearRegression()
#lin_reg_2.fit(X_poly,y)
#
#y_pred=regressor.predict(x_test)
#
#
#from sklearn.metrics import mean_squared_error,mean_absolute_error,r2_score
#print("mean squared:",np.sqrt(mean_squared_error(y_test,y_pred)))
#print("mean absolte error:",mean_absolute_error(y_test,y_pred))
#print("r2_score",r2_score(y_test,y_pred))
