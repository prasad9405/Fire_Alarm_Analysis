import time
from selenium import webdriver
browser = webdriver.Chrome(executable_path = '/home/student/Documents/Final_Project/chromedriver')
browser.get('https://data.boston.gov/dataset/ac9e373a-1303-4563-b28e-29070229fdfe/resource/e2819183-5029-42da-b9ab-2e90e044e6e3/download/property-use-code-list.csv') 
browser.get('https://data.boston.gov/dataset/ac9e373a-1303-4563-b28e-29070229fdfe/resource/29a6ef10-2e09-4e67-a4d3-9c2865c8b7ee/download/incident-type-code-list.csv') 
browser.get("https://data.boston.gov/dataset/ac9e373a-1303-4563-b28e-29070229fdfe/resource/0511abbd-d94f-49e9-b596-1e87b35a2ce8/download/january.2018-bostonfireincidentopendata.csv")
browser.get("https://data.boston.gov/dataset/ac9e373a-1303-4563-b28e-29070229fdfe/resource/8424cc7d-2592-4b82-94e7-6ac28488f80f/download/february.2018-bostonfireincidentopendata.csv")
browser.get("https://data.boston.gov/dataset/ac9e373a-1303-4563-b28e-29070229fdfe/resource/70c463da-80ec-4d40-8273-aa8d0f695095/download/march.2018-bostonfireincidentopendata.csv")
browser.get("https://data.boston.gov/dataset/ac9e373a-1303-4563-b28e-29070229fdfe/resource/8eebb3ef-c656-4c5e-b5c4-e5484e387533/download/april.2018-bostonfireincidentopendata.csv")
browser.get("https://data.boston.gov/dataset/ac9e373a-1303-4563-b28e-29070229fdfe/resource/9a3021d0-19d5-4522-9c69-7fdb9fc60ecf/download/may.2018-bostonfireincidentopendata.csv")
browser.get("https://data.boston.gov/dataset/ac9e373a-1303-4563-b28e-29070229fdfe/resource/06fcfff1-993f-461a-9d69-c38f6bc103c9/download/june.2018-bostonfireincidentopendata.csv")
browser.get("https://data.boston.gov/dataset/ac9e373a-1303-4563-b28e-29070229fdfe/resource/950a6113-b1a8-4e11-8e7e-93a1784e9906/download/july.2018-bostonfireincidentopendata.csv")
browser.get("https://data.boston.gov/dataset/ac9e373a-1303-4563-b28e-29070229fdfe/resource/2eb323d1-0df0-4e56-8496-e5c8588f667a/download/august.2018-bostonfireincidentopendata.csv")
browser.get("https://data.boston.gov/dataset/ac9e373a-1303-4563-b28e-29070229fdfe/resource/5cd71efe-77ea-48a0-bc4e-92686db26d50/download/september.2018-bostonfireincidentopendata.csv")
browser.get("https://data.boston.gov/dataset/ac9e373a-1303-4563-b28e-29070229fdfe/resource/220a4ce5-a991-4336-a19b-159881d7c2e7/download/october.2018-bostonfireincidentopendata.csv")
browser.get("https://data.boston.gov/dataset/ac9e373a-1303-4563-b28e-29070229fdfe/resource/2344310c-c9d1-4176-ad3b-ab8ec629a3ca/download/november.2018-bostonfireincidentopendata.csv")
browser.get("https://data.boston.gov/dataset/ac9e373a-1303-4563-b28e-29070229fdfe/resource/0f43b12d-ad2c-4759-8d2b-2b3b3c262082/download/december.2018-bostonfireincidentopendata.csv")
time.sleep(120)

browser.quit()


import pandas as pd
from hdfs import *
from hdfs import InsecureClient
## Dumping file into the hadoop
try:
    file1='/home/student/Downloads/property-use-code-list.csv'
    file2='/home/student/Downloads/incident-type-code-list.csv'
    file3='/home/student/Downloads/january.2018-bostonfireincidentopendata.csv'
    file4='/home/student/Downloads/february.2018-bostonfireincidentopendata.csv'
    file5='/home/student/Downloads/march.2018-bostonfireincidentopendata.csv'
    file6='/home/student/Downloads/april.2018-bostonfireincidentopendata.csv'
    file7='/home/student/Downloads/may.2018-bostonfireincidentopendata.csv'
    file8='/home/student/Downloads/june.2018-bostonfireincidentopendata.csv'
    file9='/home/student/Downloads/july.2018-bostonfireincidentopendata.csv'
    file10='/home/student/Downloads/august.2018-bostonfireincidentopendata.csv'
    file11='/home/student/Downloads/september.2018-bostonfireincidentopendata.csv'
    file12='/home/student/Downloads/october.2018-bostonfireincidentopendata.csv'
    file13='/home/student/Downloads/november.2018-bostonfireincidentopendata.csv'
    file14='/home/student/Downloads/december.2018-bostonfireincidentopendata.csv'
    
    
except:
    print("File not found")
hdfsclient=InsecureClient("http://localhost:50070",user="hduser")
hdfs_path="/"
hdfsclient.upload(hdfs_path,file1)
hdfsclient.upload(hdfs_path,file2)
hdfsclient.upload(hdfs_path,file3)
hdfsclient.upload(hdfs_path,file4)
hdfsclient.upload(hdfs_path,file5)
hdfsclient.upload(hdfs_path,file6)
hdfsclient.upload(hdfs_path,file7)
hdfsclient.upload(hdfs_path,file8)
hdfsclient.upload(hdfs_path,file9)
hdfsclient.upload(hdfs_path,file10)
hdfsclient.upload(hdfs_path,file11)
hdfsclient.upload(hdfs_path,file12)
hdfsclient.upload(hdfs_path,file13)
hdfsclient.upload(hdfs_path,file14)



import jaydebeapi
import glob

jar_files = glob.glob('/usr/local/hive/lib/*.jar')
conn_hive = jaydebeapi.connect('org.apache.hive.jdbc.HiveDriver',
        'jdbc:hive2://localhost:10000/default',['', ''], jars=jar_files)
curs_hive = conn_hive.cursor()

########################################

sql="select m.incident_number,p.descript from january2018 m left join propuse p ON (m.property_use = p.code)"
curs_hive.execute(sql)
results = curs_hive.fetchall()
print (results)

#####################create hive schema ##################################

sql="create table propuse (category string,grp int,code int,descript string) row format delimited fields terminated by ',' stored as textfile"
curs_hive.execute(sql)

sql="create table incident_type (category string,grp int,code int,descript string) row format delimited fields terminated by ',' stored as textfile"
curs_hive.execute(sql)

sql="create table jan2018 (Incident_Number string, Exposure_Number int,Alarm_Date string,Alarm_Time string,Incident_Type int,Incident_Description string,Estimated_Property_Loss int,Estimated_Content_Loss int,District int,City_Section string,Neighborhood string,Zip int,Property_Use int,Property_Description string,Street_Number string,Street_Prefix string ,Street_Name string ,Street_Suffix string,Street_Type string ,Address_2 string ,XStreet_Prefix string,XStreet_Name string,XStreet_Suffix string,XStreet_Type string) row format delimited fields terminated by ',' stored as textfile"
curs_hive.execute(sql)

sql="create table feb2018 (Incident_Number string, Exposure_Number int,Alarm_Date string,Alarm_Time string,Incident_Type int,Incident_Description string,Estimated_Property_Loss int,Estimated_Content_Loss int,District int,City_Section string,Neighborhood string,Zip int,Property_Use int,Property_Description string,Street_Number string,Street_Prefix string ,Street_Name string ,Street_Suffix string,Street_Type string ,Address_2 string ,XStreet_Prefix string,XStreet_Name string,XStreet_Suffix string,XStreet_Type string) row format delimited fields terminated by ',' stored as textfile"
curs_hive.execute(sql)

sql="create table march2018 (Incident_Number string, Exposure_Number int,Alarm_Date string,Alarm_Time string,Incident_Type int,Incident_Description string,Estimated_Property_Loss int,Estimated_Content_Loss int,District int,City_Section string,Neighborhood string,Zip int,Property_Use int,Property_Description string,Street_Number string,Street_Prefix string ,Street_Name string ,Street_Suffix string,Street_Type string ,Address_2 string ,XStreet_Prefix string,XStreet_Name string,XStreet_Suffix string,XStreet_Type string) row format delimited fields terminated by ',' stored as textfile"
curs_hive.execute(sql)

sql="create table apr2018 (Incident_Number string, Exposure_Number int,Alarm_Date string,Alarm_Time string,Incident_Type int,Incident_Description string,Estimated_Property_Loss int,Estimated_Content_Loss int,District int,City_Section string,Neighborhood string,Zip int,Property_Use int,Property_Description string,Street_Number string,Street_Prefix string ,Street_Name string ,Street_Suffix string,Street_Type string ,Address_2 string ,XStreet_Prefix string,XStreet_Name string,XStreet_Suffix string,XStreet_Type string) row format delimited fields terminated by ',' stored as textfile"
curs_hive.execute(sql)

sql="create table may2018 (Incident_Number string, Exposure_Number int,Alarm_Date string,Alarm_Time string,Incident_Type int,Incident_Description string,Estimated_Property_Loss int,Estimated_Content_Loss int,District int,City_Section string,Neighborhood string,Zip int,Property_Use int,Property_Description string,Street_Number string,Street_Prefix string ,Street_Name string ,Street_Suffix string,Street_Type string ,Address_2 string ,XStreet_Prefix string,XStreet_Name string,XStreet_Suffix string,XStreet_Type string) row format delimited fields terminated by ',' stored as textfile"
curs_hive.execute(sql)

sql="create table jun2018 (Incident_Number string, Exposure_Number int,Alarm_Date string,Alarm_Time string,Incident_Type int,Incident_Description string,Estimated_Property_Loss int,Estimated_Content_Loss int,District int,City_Section string,Neighborhood string,Zip int,Property_Use int,Property_Description string,Street_Number string,Street_Prefix string ,Street_Name string ,Street_Suffix string,Street_Type string ,Address_2 string ,XStreet_Prefix string,XStreet_Name string,XStreet_Suffix string,XStreet_Type string) row format delimited fields terminated by ',' stored as textfile"
curs_hive.execute(sql)

sql="create table jul2018 (Incident_Number string, Exposure_Number int,Alarm_Date string,Alarm_Time string,Incident_Type int,Incident_Description string,Estimated_Property_Loss int,Estimated_Content_Loss int,District int,City_Section string,Neighborhood string,Zip int,Property_Use int,Property_Description string,Street_Number string,Street_Prefix string ,Street_Name string ,Street_Suffix string,Street_Type string ,Address_2 string ,XStreet_Prefix string,XStreet_Name string,XStreet_Suffix string,XStreet_Type string) row format delimited fields terminated by ',' stored as textfile"
curs_hive.execute(sql)

sql="create table aug2018 (Incident_Number string, Exposure_Number int,Alarm_Date string,Alarm_Time string,Incident_Type int,Incident_Description string,Estimated_Property_Loss int,Estimated_Content_Loss int,District int,City_Section string,Neighborhood string,Zip int,Property_Use int,Property_Description string,Street_Number string,Street_Prefix string ,Street_Name string ,Street_Suffix string,Street_Type string ,Address_2 string ,XStreet_Prefix string,XStreet_Name string,XStreet_Suffix string,XStreet_Type string) row format delimited fields terminated by ',' stored as textfile"
curs_hive.execute(sql)

sql="create table sep2018 (Incident_Number string, Exposure_Number int,Alarm_Date string,Alarm_Time string,Incident_Type int,Incident_Description string,Estimated_Property_Loss int,Estimated_Content_Loss int,District int,City_Section string,Neighborhood string,Zip int,Property_Use int,Property_Description string,Street_Number string,Street_Prefix string ,Street_Name string ,Street_Suffix string,Street_Type string ,Address_2 string ,XStreet_Prefix string,XStreet_Name string,XStreet_Suffix string,XStreet_Type string) row format delimited fields terminated by ',' stored as textfile"
curs_hive.execute(sql)

sql="create table oct2018 (Incident_Number string, Exposure_Number int,Alarm_Date string,Alarm_Time string,Incident_Type int,Incident_Description string,Estimated_Property_Loss int,Estimated_Content_Loss int,District int,City_Section string,Neighborhood string,Zip int,Property_Use int,Property_Description string,Street_Number string,Street_Prefix string ,Street_Name string ,Street_Suffix string,Street_Type string ,Address_2 string ,XStreet_Prefix string,XStreet_Name string,XStreet_Suffix string,XStreet_Type string) row format delimited fields terminated by ',' stored as textfile"
curs_hive.execute(sql)

sql="create table nov2018 (Incident_Number string, Exposure_Number int,Alarm_Date string,Alarm_Time string,Incident_Type int,Incident_Description string,Estimated_Property_Loss int,Estimated_Content_Loss int,District int,City_Section string,Neighborhood string,Zip int,Property_Use int,Property_Description string,Street_Number string,Street_Prefix string ,Street_Name string ,Street_Suffix string,Street_Type string ,Address_2 string ,XStreet_Prefix string,XStreet_Name string,XStreet_Suffix string,XStreet_Type string) row format delimited fields terminated by ',' stored as textfile"
curs_hive.execute(sql)

sql="create table dec2018 (Incident_Number string, Exposure_Number int,Alarm_Date string,Alarm_Time string,Incident_Type int,Incident_Description string,Estimated_Property_Loss int,Estimated_Content_Loss int,District int,City_Section string,Neighborhood string,Zip int,Property_Use int,Property_Description string,Street_Number string,Street_Prefix string ,Street_Name string ,Street_Suffix string,Street_Type string ,Address_2 string ,XStreet_Prefix string,XStreet_Name string,XStreet_Suffix string,XStreet_Type string) row format delimited fields terminated by ',' stored as textfile"
curs_hive.execute(sql)


###########load data in created schema#########################
sql="load data inpath '/property-use-code-list.csv' into table propuse"
curs_hive.execute(sql)

sql="load data inpath '/incident-type-code-list.csv' into table incident_type"
curs_hive.execute(sql)

sql="load data inpath '/january.2018-bostonfireincidentopendata.csv' into table jan2018"
curs_hive.execute(sql)

sql="load data inpath '/february.2018-bostonfireincidentopendata.csv' into table feb2018"
curs_hive.execute(sql)

sql="load data inpath '/march.2018-bostonfireincidentopendata.csv' into table mar2018"
curs_hive.execute(sql)

sql="load data inpath '/april.2018-bostonfireincidentopendata.csv' into table apr2018"
curs_hive.execute(sql)

sql="load data inpath '/may.2018-bostonfireincidentopendata.csv' into table may2018"
curs_hive.execute(sql)

sql="load data inpath '/june.2018-bostonfireincidentopendata.csv' into table jun2018"
curs_hive.execute(sql)

sql="load data inpath '/july.2018-bostonfireincidentopendata.csv' into table jul2018"
curs_hive.execute(sql)

sql="load data inpath '/august.2018-bostonfireincidentopendata.csv' into table aug2018"
curs_hive.execute(sql)

sql="load data inpath '/september.2018-bostonfireincidentopendata.csv' into table sep2018"
curs_hive.execute(sql)

sql="load data inpath '/october.2018-bostonfireincidentopendata.csv' into table oct2018"
curs_hive.execute(sql)

sql="load data inpath '/november.2018-bostonfireincidentopendata.csv' into table nov2018"
curs_hive.execute(sql)

sql="load data inpath '/december.2018-bostonfireincidentopendata.csv' into table dec2018"
curs_hive.execute(sql)





#results = curs_hive.fetchall()
#df=pd.DataFrame(results)
#print (results)
#pd.DataFrame

sql="load data local inpath '/tmp/january2018.csv' into table january2018"
curs_hive.execute(sql)
#LOAD DATA LOCAL INPATH '%s' INTO TABLE %s

sql="create table demo1 as (select m.incident_number,p.descript from january2018 m left join propuse p ON (m.property_use = p.code))"
curs_hive.execute(sql)

sql=""
